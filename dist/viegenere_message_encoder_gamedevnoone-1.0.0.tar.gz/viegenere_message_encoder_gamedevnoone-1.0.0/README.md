# Vigener_Coder_n_Decoder
 It's a program which can encode and decode Viegener codes

![alt text](https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/61ed27ee-1b3a-4a38-b9a4-d2d72757fc83/d2lsxe8-f704f619-9c36-4832-9fd5-12176b43bd74.jpg/v1/fill/w_614,h_650,q_75,strp/chibi_miku_by_tonee89_d2lsxe8-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NjUwIiwicGF0aCI6IlwvZlwvNjFlZDI3ZWUtMWIzYS00YTM4LWI5YTQtZDJkNzI3NTdmYzgzXC9kMmxzeGU4LWY3MDRmNjE5LTljMzYtNDgzMi05ZmQ1LTEyMTc2YjQzYmQ3NC5qcGciLCJ3aWR0aCI6Ijw9NjE0In1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmltYWdlLm9wZXJhdGlvbnMiXX0.iFgscbAyY4zPPpgJTSv939myU68wwRaF9yyzX_U4QIQ "I'm a retard, damn")

It's pretty straightforward to be honest but filled with my autism and idiotism.

![alt text](https://images.fineartamerica.com/images/artworkimages/mediumlarge/3/smug-megumin-gun-konosuba-design-konosuba.jpg "Damn I might be")

## Help and User Instructions

The Basic controls are:\
`E for Encoding, D for Decoding, E to Exit and C for Credits`

Check the Alphabet in the ***General_Purpose_Lib*** for forbidden symbols (If it's **not** in it **must not be used**)

**Do not use forbidden symbols in the Message or the Keywords** (Update pending, some try:except to add and done)

**Must have Python installed to use this program!!!**

## Thank you for using or even just checking this shit

Yeah thanks, the title says it all

It's basically a personal project of mine done in two days cause why not.

I'll make quite a lot of more command line programs in the future so that I can avoid my actual work 

![alt text](https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ftse1.mm.bing.net%2Fth%3Fid%3DOIP.g6cQXHQaejH2PA9APuIsewHaEJ%26pid%3DApi&f=1&ipt=3573763e9d7c5aca590175af0949e696c3b255ddba8ca03cff1c07927b2dcf86&ipo=images "I'm stupid")