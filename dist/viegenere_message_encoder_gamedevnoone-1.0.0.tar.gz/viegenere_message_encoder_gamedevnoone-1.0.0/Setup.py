from setuptools import setup, find_packages

setup(
    name= "Viegenere_Coder_and_Encoder",
    version= "1.0",
    description= "Codes and decodes messages",
    author= "No One",
    author_email= "noonegamedev1@gmail.com",
    packages= find_packages(),
    install_requires= ["alive_progress"],
)